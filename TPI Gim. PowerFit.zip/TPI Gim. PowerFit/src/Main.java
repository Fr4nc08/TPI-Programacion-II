import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== GESTIÓN GIMNASIO POWERPITEFIT ===\n");

        // 1. Crear un Entrenador (Aplica Herencia de Persona)
        Entrenador entrenador1 = new Entrenador(1, "Carlos", "Pérez", "30123456", "3534001122", "Musculación y Funcional");
        System.out.println("Entrenador registrado: " + entrenador1.getNombre() + " " + entrenador1.getApellido());

        // 2. Crear Socios (Aplica Herencia de Persona)
        Socio socio1 = new Socio(101, "Gastón", "Gómez", "40111222", "3534556677", "gaston@email.com", LocalDate.of(1998, 5, 15));
        Socio socio2 = new Socio(102, "Mateo", "López", "41222333", "3534889900", "mateo@email.com", LocalDate.of(2000, 8, 20));

        // 3. Crear Membresías (Aplica Enumeración TipoMembresia)
        // Socio 1: Membresía ACTIVA (vence el mes que viene)
        Membresia membresiaActiva = new Membresia(1, TipoMembresia.MENSUAL, LocalDate.now().minusDays(5), LocalDate.now().plusDays(25), 15000.0);
        socio1.asignarmembresia(membresiaActiva);

        // Socio 2: Membresía VENCIDA (venció hace 5 días)
        Membresia membresiaVencida = new Membresia(2, TipoMembresia.MENSUAL, LocalDate.now().minusDays(35), LocalDate.now().minusDays(5), 15000.0);
        socio2.asignarmembresia(membresiaVencida);

        System.out.println("Socio 1 (" + socio1.getNombre() + ") ¿Tiene membresía activa?: " + socio1.tieneMembresiaActiva());
        System.out.println("Socio 2 (" + socio2.getNombre() + ") ¿Tiene membresía activa?: " + socio2.tieneMembresiaActiva());
        System.out.println("--------------------------------------------------\n");

        // 4. Crear una Clase Grupal con Cupo Máximo de 1 persona para probar límites
        ClaseGrupal claseCrossfit = new ClaseGrupal(1, "Crossfit", "09:00 hs", 1);
        System.out.println("Clase creada: " + "Crossfit | Cupos totales: 1");

        // 5. PRUEBA DE REGLAS DE NEGOCIO:

        // Intentar inscribir a Socio 2 (Membresía vencida) -> Debería fallar (Regla 1)
        System.out.println("\nIntentando inscribir a " + socio2.getNombre() + " (Membresía Vencida)...");
        boolean exitoSocio2 = claseCrossfit.inscribirSocio(socio2);
        if (exitoSocio2) {
            System.out.println("-> Inscripción exitosa.");
        } else {
            System.out.println("-> ERROR: No se puede inscribir. El socio no tiene la membresía al día.");
        }

        // Intentar inscribir a Socio 1 (Membresía activa) -> Debería ser exitoso
        System.out.println("\nIntentando inscribir a " + socio1.getNombre() + " (Membresía Activa)...");
        boolean exitoSocio1 = claseCrossfit.inscribirSocio(socio1);
        if (exitoSocio1) {
            System.out.println("-> Inscripción exitosa.");
        } else {
            System.out.println("-> ERROR: No se pudo inscribir.");
        }

        // Intentar inscribir a otro socio cuando el cupo ya está lleno -> Debería fallar (Regla 3)
        Socio socio3 = new Socio(103, "Franco", "Rodríguez", "42333444", "3534112233", "franco@email.com", LocalDate.of(1999, 3, 10));
        Membresia membresiaSocio3 = new Membresia(3, TipoMembresia.TRIMESTRAL, LocalDate.now(), LocalDate.now().plusMonths(3), 40000.0);
        socio3.asignarmembresia(membresiaSocio3);

        System.out.println("\nIntentando inscribir a " + socio3.getNombre() + " a una clase sin cupos...");
        boolean exitoSocio3 = claseCrossfit.inscribirSocio(socio3);
        if (exitoSocio3) {
            System.out.println("-> Inscripción exitosa.");
        } else {
            System.out.println("-> ERROR: No se puede inscribir. La clase no tiene cupos disponibles.");
        }

        System.out.println("\nCupos restantes en la clase: " + claseCrossfit.getCuposDisponibles());
    }
}
import java.time.LocalDate;

public class Membresia {
    private int id;
    private TipoMembresia tipo;
    private LocalDate fechaInicio;
    private LocalDate fechaVencimiento;
    private double precio;

    public Membresia(int id, TipoMembresia tipo, LocalDate fechaInicio, LocalDate fechaVencimiento, double precio) {
        this.id = id;
        this.tipo = tipo;
        this.fechaInicio = fechaInicio;
        this.fechaVencimiento = fechaVencimiento;
        this.precio = precio;
    }

    public boolean isActiva() {
        return LocalDate.now().isBefore(fechaVencimiento) || LocalDate.now().isEqual(fechaVencimiento);
    }

    public TipoMembresia getTipo() { return tipo; }
    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
}
public class Entrenador extends Persona {
    private String especialidad;

    public Entrenador(int id, String nombre, String apellido, String dni, String telefono, String especialidad) {
        super(id, nombre, apellido, dni, telefono);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }
}
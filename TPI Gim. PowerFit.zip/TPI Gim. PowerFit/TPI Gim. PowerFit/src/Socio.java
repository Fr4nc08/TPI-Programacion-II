import java.time.LocalDate;

public class Socio extends Persona {
    private String email;
    private LocalDate fechaNacimiento;
    private Membresia membresiaActual;

    public Socio(int id, String nombre, String apellido, String dni, String telefono, String email, LocalDate fechaNacimiento) {
        super(id, nombre, apellido, dni, telefono);
        this.email = email;
        this.fechaNacimiento = fechaNacimiento;
    }

    public boolean tieneMembresiaActiva() {
        return membresiaActual != null && membresiaActual.isActiva();
    }

    public void asignarmembresia(Membresia membresia) {
        this.membresiaActual = membresia;
    }

    public Membresia getMembresiaActual() { return membresiaActual; }

    public String getEmail(){return email;}

    public LocalDate getFechaNacimiento(){return fechaNacimiento;}
}
import java.util.ArrayList;
import java.util.List;

public class ClaseGrupal {
    private int id;
    private String nombre;
    private String horario;
    private int cupoMaximo;
    private List<Socio> inscriptos;

    public ClaseGrupal(int id, String nombre, String horario, int cupoMaximo) {
        this.id = id;
        this.nombre = nombre;
        this.horario = horario;
        this.cupoMaximo = cupoMaximo;
        this.inscriptos = new ArrayList<>();
    }

    public int getId(){return id;}
    
    public String getNombre(){return nombre;}

    public String getHorario(){return horario;}

    public boolean inscribirSocio(Socio socio) {
        if (!socio.tieneMembresiaActiva()) {
            return false; // Regla 1: No asiste si la membresía está vencida
        }
        if (inscriptos.size() >= cupoMaximo) {
            return false; // Regla 3: Solo si quedan cupos
        }
        inscriptos.add(socio);
        return true;
    }

    public int getCuposDisponibles() {
        return cupoMaximo - inscriptos.size();
    }
}